===================================
README
===================================

System Requirement:
-----------------------------------
Matlab versions 6.5.1 or upper.
SPM5 or SPM8 added to MATLAB path.



Steps to run batch codes:
----------------------------------

1. Put folder batch_scripts into the 
   same folder where subject 
   folders(sub1, sub2, etc.) are.
3. Run batch_run.m in MATLAB
